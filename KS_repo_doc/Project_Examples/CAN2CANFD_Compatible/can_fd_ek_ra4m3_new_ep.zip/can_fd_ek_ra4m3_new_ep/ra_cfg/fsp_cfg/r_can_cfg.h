/* generated configuration header file - do not edit */
#ifndef R_CAN_CFG_H_
#define R_CAN_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define CAN_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define CAN_CFG_FIFO_SUPPORT          (0)

#ifdef __cplusplus
            }
            #endif
#endif /* R_CAN_CFG_H_ */
